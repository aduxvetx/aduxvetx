import 'package:intl/intl.dart';

class TimeFormatter {
  static String format(DateTime time) {
    return DateFormat('hh:mm a').format(time);
  }
}