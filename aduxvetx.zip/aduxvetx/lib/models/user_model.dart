class UserModel {
  final String id;
  final String name;
  final String phone;
  final String imageUrl;
  final bool isAdmin;

  UserModel({
    required this.id,
    required this.name,
    required this.phone,
    required this.imageUrl,
    required this.isAdmin,
  });

  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      id: map['id'],
      name: map['name'],
      phone: map['phone'],
      imageUrl: map['imageUrl'],
      isAdmin: map['isAdmin'] ?? false,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'phone': phone,
      'imageUrl': imageUrl,
      'isAdmin': isAdmin,
    };
  }
}