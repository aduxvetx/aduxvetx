import 'package:flutter/material.dart';

class StatusTile extends StatelessWidget {
  final String userName;
  final String imageUrl;

  const StatusTile({required this.userName, required this.imageUrl});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: CircleAvatar(
        backgroundImage: NetworkImage(imageUrl),
      ),
      title: Text(userName, style: TextStyle(color: Colors.white)),
    );
  }
}