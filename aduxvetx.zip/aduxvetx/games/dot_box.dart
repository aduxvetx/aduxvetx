import 'package:flutter/material.dart';

class DotBoxGame extends StatefulWidget {
  @override
  _DotBoxGameState createState() => _DotBoxGameState();
}

class _DotBoxGameState extends State<DotBoxGame> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Dot & Box")),
      body: Center(
        child: Text(
          "Dot & Box Game Coming Soon!",
          style: TextStyle(fontSize: 20),
        ),
      ),
    );
  }
}