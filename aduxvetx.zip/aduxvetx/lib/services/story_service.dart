import 'package:cloud_firestore/cloud_firestore.dart';

class StoryService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> addStory(String userId, Map<String, dynamic> storyData) async {
    await _firestore.collection('stories').doc(userId).set(storyData);
  }

  Stream<QuerySnapshot> getStories() {
    return _firestore.collection('stories').snapshots();
  }

  Future<void> deleteStory(String userId) async {
    await _firestore.collection('stories').doc(userId).delete();
  }
}