import 'package:flutter/material.dart';

class GameScreen extends StatelessWidget {
  void _showComingSoon(BuildContext context, String gameName) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('$gameName launching soon!')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final games = [
      {'title': 'Tic Tac Toe', 'icon': Icons.grid_3x3},
      {'title': 'Rock Paper Scissors', 'icon': Icons.pan_tool},
      {'title': 'Quiz Battle', 'icon': Icons.quiz},
      {'title': 'Dot & Box', 'icon': Icons.grid_on},
    ];

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text('Games'),
        backgroundColor: Colors.black,
      ),
      body: ListView.builder(
        itemCount: games.length,
        itemBuilder: (context, index) {
          final game = games[index];
          return Card(
            color: Colors.white10,
            child: ListTile(
              leading: Icon(game['icon'] as IconData, color: Colors.white),
              title: Text(game['title'] as String,
                  style: TextStyle(color: Colors.white)),
              trailing: ElevatedButton(
                onPressed: () =>
                    _showComingSoon(context, game['title'] as String),
                child: Text('Play'),
              ),
            ),
          );
        },
      ),
    );
  }
}