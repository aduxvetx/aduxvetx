import 'package:flutter/material.dart';

class QuizBattleGame extends StatefulWidget {
  @override
  _QuizBattleGameState createState() => _QuizBattleGameState();
}

class _QuizBattleGameState extends State<QuizBattleGame> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Quiz Battle")),
      body: Center(
        child: Text(
          "Quiz Battle Coming Soon!",
          style: TextStyle(fontSize: 20),
        ),
      ),
    );
  }
}