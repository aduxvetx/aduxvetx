import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class ProfileScreen extends StatelessWidget {
  final bool isAdmin;

  ProfileScreen({required this.isAdmin});

  final Uri _instagramUri = Uri.parse(
    'https://www.instagram.com/ix_adityaa/profilecard/?igsh=MW13OWw2eTJma3oyaw==',
  );

  void _openInstagram(BuildContext context) async {
    if (await canLaunchUrl(_instagramUri)) {
      await launchUrl(_instagramUri, mode: LaunchMode.externalApplication);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not launch Instagram')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Profile Image
            CircleAvatar(
              backgroundImage: AssetImage('assets/images/logo.png'),
              radius: 60,
            ),
            SizedBox(height: 12),
            // Name
            Text(
              isAdmin ? 'Admin: Aditya' : 'User',
              style: TextStyle(color: Colors.white, fontSize: 24),
            ),
            // Verified Badge
            if (isAdmin)
              Icon(Icons.verified, color: Colors.blueAccent, size: 24),
            SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: () => _openInstagram(context),
              icon: Icon(Icons.contact_page),
              label: Text('Contact to Admin'),
            ),
          ],
        ),
      ),
    );
  }
}