import 'package:flutter/material.dart';

class RockPaperScissorsGame extends StatefulWidget {
  @override
  _RockPaperScissorsGameState createState() => _RockPaperScissorsGameState();
}

class _RockPaperScissorsGameState extends State<RockPaperScissorsGame> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Rock Paper Scissors")),
      body: Center(
        child: Text(
          "Rock Paper Scissors Coming Soon!",
          style: TextStyle(fontSize: 20),
        ),
      ),
    );
  }
}