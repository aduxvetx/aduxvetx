import 'package:cloud_firestore/cloud_firestore.dart';

class GameService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> createGame(String gameId, Map<String, dynamic> gameData) async {
    await _firestore.collection('games').doc(gameId).set(gameData);
  }

  Future<void> updateGame(String gameId, Map<String, dynamic> updates) async {
    await _firestore.collection('games').doc(gameId).update(updates);
  }

  Stream<DocumentSnapshot> getGameStream(String gameId) {
    return _firestore.collection('games').doc(gameId).snapshots();
  }

  Future<void> deleteGame(String gameId) async {
    await _firestore.collection('games').doc(gameId).delete();
  }
}