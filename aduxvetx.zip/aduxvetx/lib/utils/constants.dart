import 'package:flutter/material.dart';

const kPrimaryColor = Colors.blueAccent;
const kSecondaryColor = Colors.black87;
const kBackgroundColor = Colors.white;

const String appName = "Adux Vetx";
const String adminUsername = "aditya7";
const String adminPassword = "adux70";
const String userPassword = "adux70";